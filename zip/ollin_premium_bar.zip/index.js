window.addEventListener("load", function() {

	let banner;
	let tlTags;
	let tlPetals;
	let tlBottles;
	let mouseLeaveTimeout;
	let mouseEnterTimeout;
	let hideBottlesTimeout;
	let showBottlesTimeout;
	let toggler;
	let firstLoadFlag = true;

	animateOnLoad();	

	function animateOnLoad() {

		banner = document.querySelector(".ollincd");
		if(!banner) return;

		banner.classList.add("ollincd-loaded");
		setTimeout(() => {			
			animatePetals();
			animateBottlesOnWheel();
		}, 1000);
	}


	function animateTags() {
		_f();
		
		function _f() {

			if(!document.querySelector(".ollincd-tag")) return;
			if(tlTags) tlTags.kill();

			let _scale;
			if(window.matchMedia('(min-width:600px)').matches) {
				_scale = 1.22;
			}
			else {
				_scale = 1.1;
			}
	
			let tags = gsap.utils.toArray(document.querySelectorAll(".ollincd-tag"));
			tlTags = gsap.timeline({onComplete: _f, repeatRefresh: true});
	
			tlTags
				.to(tags, {
					x: "random(-12, 12)",
					y: "random(-7, 7)",				
					transformOrigin: "50% 50%",
					ease: "none",
					duration: 4,
					repeat: 0
				})
				.to(tags, {
					scale: _scale,
					duration: 1
				}, "<")
		}
	}
	function resetTags() {
		if(!document.querySelector(".ollincd-tag")) return;
		if(tlTags) tlTags.kill();
		let tags = gsap.utils.toArray(document.querySelectorAll(".ollincd-tag"));
		tags.forEach((tag) => {
			gsap.to(tag, {
				x: 0,
				y: 0,
				scale: 1
			})
		})
	}


	function animatePetals() {
		if(banner.classList.contains("ollincd-hovered") || !banner.classList.contains("ollincd-showup")) return;
		let _x, _scale;
		if(window.matchMedia('(min-width:600px)').matches) {
			_x = "random(-12, 35)";
			_scale = "random(.8, 1.2)";
		}
		else {
			_x = "random(-12, 35)";
			_scale = "random(.8, 1.04)";
		}

		_f();
		
		function _f() {
			if(!document.querySelector(".ollincd-petal")) return;
			if(tlPetals) tlPetals.kill();

			let petals = gsap.utils.toArray(document.querySelectorAll(".ollincd-petal .ollincd-petal-inner"));
			gsap.set(petals, { scaleY: 1, transformOrigin: "50% 100%" });
			tlPetals = gsap.timeline({onComplete: _f, repeatRefresh: true});

			tlPetals.to(petals, {
				x: _x,
				scaleX: _scale,
				scaleY: 1,
				ease: "none",
				duration: 3,
				repeat: 0
			})
		}
	}
	


	function animateBottlesOnWheel() {
		gsap.registerPlugin(Observer);

		const items = gsap.utils.toArray(banner.querySelectorAll(".ollincd-bottle"));

		let current = 0;
		let isAnimating = false;

		if(firstLoadFlag) {
			firstLoadFlag = false;
			gsap.set(items[current], { autoAlpha: 0, scale:.8, x:"-100%" });
			gsap.to(items[current], {
				autoAlpha: 1,
				scale: 1,
				x: 0,
				duration: .4
			})
		}

		items[current].classList.add("active");

		function show(index, direction) {
			if(banner.classList.contains("ollincd-showBottles")) return;
			if (isAnimating || index === current) return;

			isAnimating = true;

			const currentItem = items[current];
			const nextItem = items[index];

			const tl = gsap.timeline({
				onComplete() {
					banner.querySelector(".ollincd-bottle.active").classList.remove("active");
					current = index;
					isAnimating = false;
					items[current].classList.add("active");
					items.forEach((item, i) => {
						if(i != current) {
							item.removeAttribute("style");
						}
						item.querySelector("img").removeAttribute("style");
					})
				}
			});

			tl.to(currentItem, {
				autoAlpha: 0,
				x: "100%",
				scale: .8,
				duration: 0.35
			});

			tl.fromTo(nextItem,
				{
					autoAlpha: 0,
					x: "-100%",
					scale: .8
				},
				{
					autoAlpha: 1,
					x: 0,
					scale: 1,
					duration: 0.35
				},
				"<"
			);
		}

		const observer = Observer.create({

			target: window,

			type: "wheel,touch",

			tolerance: 100,

			onDown() {
				// Fully expanded banner ignores scroll.
				if (banner.classList.contains("ollincd-showBottles") || banner.classList.contains("ollincd-hovered")) return;

				const next = (current + 1) % items.length;
				show(next, 1);
			},

			onUp() {
				if (banner.classList.contains("ollincd-showBottles") || banner.classList.contains("ollincd-hovered")) return;

				const next = (current + 1) % items.length;
				show(next, 1);
			}
		});		
	}

	if(toggler = document.querySelector(".ollincd-toggler")) {
		toggler.addEventListener("click", (event) => {
			event.preventDefault();
			event.stopPropagation();
			
			const btn = event.target;
			const expanded = btn.getAttribute('aria-expanded') === 'true';
			btn.setAttribute('aria-expanded', !expanded);
			
			if(!expanded) {
				clearTimeout(mouseEnterTimeout);					
				banner.classList.add("ollincd-hovered");
				if(tlPetals) tlPetals.kill();
				ollincd.expand();
			}
			else {
				clearTimeout(mouseLeaveTimeout);
				if(tlPetals) tlPetals.kill();
				if(tlTags) tlTags.kill();
				banner.classList.remove("ollincd-hovered"); 
				banner.classList.add("ollincd-unhover");				
				
				mouseLeaveTimeout = setTimeout(() => {
					banner.classList.remove("ollincd-unhover");
					animatePetals();
				}, 50);

				ollincd.collapse();	
			}
		})
	}

	if(banner = document.querySelector(".ollincd")) {
		banner.classList.add("ollincd-showup");
		if (window.matchMedia("(min-width:600px)").matches) {
			banner.addEventListener("mouseenter", function() {
				ollincd.expand();
			});
			banner.addEventListener("mouseleave", function() {
				ollincd.collapse();
			});
		}
	}
	var ollincd = {		
		
		showBottles: function(banner) {
			if(!banner.querySelector(".ollincd-bottle")) return;

			clearTimeout(hideBottlesTimeout);
			clearTimeout(showBottlesTimeout);

			bottlesConts = gsap.utils.toArray(banner.querySelectorAll(".ollincd-bottle"));
			bottlesConts.forEach((item) => {
				if(!item.classList.contains("active")) {
					item.removeAttribute("style");
				}
			})
			banner.classList.remove("ollincd-hideBottles");
			banner.classList.add("ollincd-showBottles");
	
			bottles = gsap.utils.toArray(banner.querySelectorAll(".ollincd-bottle img"));
	
			gsap.set(bottles, {scale:1, y:"100%", opacity:1, rotate: 3});

			showBottlesTimeout = setTimeout(_f, 0);

			animateTags();
	
			function _f() {	
				tlBottles = gsap.timeline()
				tlBottles.to(bottles, {
					duration: 1.5,
					y: 0,
					opacity: 1,
					rotate: 3,
					ease: "elastic.out(.1)",
					stagger: .15
				});
			}
		},
		hideBottles: function(banner) {
			tlBottles.pause();
			tlBottles.kill();
	
			banner.classList.add("ollincd-hideBottles");

			let bottles = gsap.utils.toArray(banner.querySelectorAll(".ollincd-bottle img"));

			let p1 = new Promise((resolve, rejuct) => {
				hideBottlesTimeout = setTimeout(() => {_f(); resolve()}, 400);
			})
			p1.then(() => {
				gsap.set(bottles, {scale:1, y:0, opacity:0, rotate:0});
				gsap.to(bottles, {
					opacity: 1,
					duration: .5,
					onComplete: () => {
						bottles.forEach((bottle) => {
							bottle.removeAttribute("style");
						});	
					}
				})
			}) 

			function _f() {
				banner.classList.remove("ollincd-showBottles");
				banner.classList.remove("ollincd-hideBottles");
				bottles.forEach((bottle) => {
					bottle.removeAttribute("style");
				});				
			}
		},
		expand: function() {
			clearTimeout(mouseEnterTimeout);
			mouseEnterTimeout = setTimeout(() => {
				banner.classList.add("ollincd-hovered");					
				if(tlPetals) tlPetals.kill();
			}, 0);
			ollincd.showBottles(banner);
		},
		collapse: function() {
			clearTimeout(mouseLeaveTimeout);
			if(tlPetals) tlPetals.kill();
			if(tlTags) tlTags.kill();
			banner.classList.remove("ollincd-hovered"); 
			banner.classList.add("ollincd-unhover");				
			
			mouseLeaveTimeout = setTimeout(() => {
				banner.classList.remove("ollincd-unhover");
				animatePetals();
				resetTags();
			}, 50);

			ollincd.hideBottles(banner);
		}
	}
})


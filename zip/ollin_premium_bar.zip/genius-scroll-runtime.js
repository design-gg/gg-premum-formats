/**
 * genius-scroll-runtime.js (delivery 1.2)
 *
 * Reusable banner-side module: binds creative timelines to parent scroll progress.
 * Parent (genius-components / ScrollStatePublisher) posts `genius-scroll-state`;
 * this runtime applies progress to a GSAP timeline or a custom handler.
 *
 * Not tied to a specific creative — any banner can:
 *   1. Set window.GENIUS_SCROLL_CONFIG
 *   2. Include this script
 *   3. Call GeniusScroll.initTimeline(tl) or GeniusScroll.onProgress(fn)
 */
(function () {
  'use strict';

  var DEFAULT_CONFIG = {
    mode: 'off', // 'timeline' | 'videoBar' | 'ticks' | 'off'
    binding: 'scrub', // 'scrub' | 'ticks' (auto when mode === 'ticks')
    devices: ['mobile', 'desktop'],
    screenCount: 2,
    videoBar: {
      startHeightRatio: 0.25,
      minHeightPx: 60,
      shrinkScrollPx: 300,
    },
    ticks: {
      // Viewport-heights scrolled (bridge progressMode: 'viewport' for scroll-mode=ticks).
      thresholds: [1, 2, 3],
      hysteresis: 0.12,
    },
  };

  var timeline = null;
  var progressHandlers = [];
  var tickHandlers = { onForward: null, onReverse: null };
  var tickState = { index: 0, lastProgress: 0 };
  var lastState = null;

  function getConfig() {
    var user = window.GENIUS_SCROLL_CONFIG || {};
    var merged = {};
    var key;
    for (key in DEFAULT_CONFIG) {
      if (Object.prototype.hasOwnProperty.call(DEFAULT_CONFIG, key)) {
        merged[key] = DEFAULT_CONFIG[key];
      }
    }
    for (key in user) {
      if (Object.prototype.hasOwnProperty.call(user, key)) {
        if (key === 'ticks' && user.ticks && typeof user.ticks === 'object') {
          merged.ticks = Object.assign({}, DEFAULT_CONFIG.ticks, user.ticks);
        } else if (key === 'videoBar' && user.videoBar && typeof user.videoBar === 'object') {
          merged.videoBar = Object.assign({}, DEFAULT_CONFIG.videoBar, user.videoBar);
        } else {
          merged[key] = user[key];
        }
      }
    }
    return merged;
  }

  function isDeviceAllowed(device) {
    var devices = getConfig().devices;
    return !devices || devices.indexOf(device) !== -1;
  }

  function applyProgress(progress, state) {
    if (timeline && typeof timeline.progress === 'function') {
      timeline.progress(progress);
    }
    for (var i = 0; i < progressHandlers.length; i++) {
      try {
        progressHandlers[i](progress, state);
      } catch (err) {
        console.error('[GeniusScroll] onProgress handler error', err);
      }
    }
  }

  function usesTicks(config) {
    return config.mode === 'ticks' || config.binding === 'ticks';
  }

  /** Map page/container progress to discrete tick 0..N via thresholds + hysteresis. */
  function computeTickIndex(progress, thresholds, hysteresis, lastProgress, currentIndex) {
    var h = hysteresis || 0;
    var idx = currentIndex != null ? currentIndex : 0;
    var goingForward = progress >= lastProgress;

    for (var i = 0; i < thresholds.length; i++) {
      var edge = thresholds[i];
      var step = i + 1;
      if (goingForward) {
        // Fire as soon as the viewport threshold is reached.
        if (progress >= edge && idx < step) idx = step;
      } else if (progress <= edge - h && idx >= step) {
        idx = step - 1;
      }
    }
    return idx;
  }

  function applyTicks(progress, state) {
    var config = getConfig();
    var thresholds = (config.ticks && config.ticks.thresholds) || DEFAULT_CONFIG.ticks.thresholds;
    var hysteresis = (config.ticks && config.ticks.hysteresis) != null
      ? config.ticks.hysteresis
      : DEFAULT_CONFIG.ticks.hysteresis;
    var newIndex = computeTickIndex(
      progress,
      thresholds,
      hysteresis,
      tickState.lastProgress,
      tickState.index
    );

    if (newIndex !== tickState.index) {
      var dir = newIndex > tickState.index ? 1 : -1;
      var step = tickState.index;
      while (step !== newIndex) {
        var next = step + dir;
        try {
          if (dir > 0 && typeof tickHandlers.onForward === 'function') {
            tickHandlers.onForward(step, next, progress, state);
          } else if (dir < 0 && typeof tickHandlers.onReverse === 'function') {
            tickHandlers.onReverse(step, next, progress, state);
          }
        } catch (err) {
          console.error('[GeniusScroll] tick handler error', err);
        }
        step = next;
      }
      tickState.index = newIndex;
    }

    tickState.lastProgress = progress;
  }

  function handleState(state) {
    if (!state || state.type !== 'genius-scroll-state') return;

    var config = getConfig();
    if (!isDeviceAllowed(state.device)) return;

    lastState = state;

    if (config.mode === 'off') return;

    if (usesTicks(config)) {
      applyTicks(state.progress, state);
      return;
    }

    // timeline / videoBar: direct scrub via GSAP timeline and onProgress handlers.
    if (config.mode === 'timeline' || config.mode === 'videoBar') {
      applyProgress(state.progress, state);
    }
  }

  function notifyReady() {
    if (window.parent !== window) {
      window.parent.postMessage({ type: 'genius-banner-ready' }, '*');
    }
  }

  function init() {
    window.addEventListener('message', function (event) {
      handleState(event.data);
    });
    notifyReady();
  }

  /**
   * Public API for banner authors (stable contract).
   */
  window.GeniusScroll = {
    /** Merge / replace GENIUS_SCROLL_CONFIG at runtime */
    setConfig: function (next) {
      window.GENIUS_SCROLL_CONFIG = Object.assign({}, getConfig(), next || {});
    },

    getConfig: function () {
      return getConfig();
    },

    /** Last genius-scroll-state payload (or null) */
    getState: function () {
      return lastState;
    },

    getTickIndex: function () {
      return tickState.index;
    },

    /**
     * Bind a paused GSAP timeline (or any object with .progress(0..1)).
     * Re-applies last known progress if parent already scrolled.
     */
    initTimeline: function (tl) {
      timeline = tl;
      window.__geniusTimeline = tl;
      if (lastState && getConfig().mode !== 'off' && !usesTicks(getConfig())) {
        applyProgress(lastState.progress, lastState);
      }
      notifyReady();
      return this;
    },

    /**
     * Tick mode: discrete animation steps at scroll thresholds (not direct scrub).
     * handlers: { onForward(from, to, progress, state), onReverse(from, to, progress, state) }
     */
    initTicks: function (handlers) {
      handlers = handlers || {};
      tickHandlers.onForward = handlers.onForward || null;
      tickHandlers.onReverse = handlers.onReverse || null;
      tickState.index = 0;
      tickState.lastProgress = lastState ? lastState.progress : 0;
      if (lastState && usesTicks(getConfig())) {
        applyTicks(lastState.progress, lastState);
      }
      notifyReady();
      return this;
    },

    /**
     * Subscribe to progress without GSAP.
     * handler(progress: number, state: GeniusScrollState)
     * Returns unsubscribe function.
     */
    onProgress: function (handler) {
      if (typeof handler !== 'function') return function () {};
      progressHandlers.push(handler);
      if (lastState && getConfig().mode !== 'off' && !usesTicks(getConfig())) {
        handler(lastState.progress, lastState);
      }
      return function unsubscribe() {
        progressHandlers = progressHandlers.filter(function (h) {
          return h !== handler;
        });
      };
    },
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  /** Premium bar: pink strip stays ~80px; iframe taller so bottles/petals can protrude. */
  function setupPremiumBarExpandedResize() {
    var target = document.querySelector('#inner');
    if (!target || !document.querySelector('.ollincd')) return;

    var prev = 0;
    // Collapsed: pink ~80px + bottle protrusion (~120–140px tall, bottom-aligned).
    var COLLAPSED_MAX = 180;
    var EXPANDED_MAX = 440;
    var COLLAPSED_MIN = 150;

    function measure() {
      var banner = document.querySelector('.ollincd');
      var baseRect = target.getBoundingClientRect();
      var minTop = 0;
      var maxBottom = target.offsetHeight;
      var expanded =
        banner &&
        (banner.classList.contains('ollincd-hovered') ||
          banner.classList.contains('ollincd-showBottles'));

      // Always include protruding bottles/petals (collapsed) — pink stays 80px via CSS.
      target
        .querySelectorAll(
          '.ollincd-bottle, .ollincd-bottle img, .ollincd-petal, .ollincd-petal-inner, .ollincd-bg, .ollincd-logo, .ollincd-tag, .ollincd-toggler'
        )
        .forEach(function (el) {
          var cs = getComputedStyle(el);
          if (cs.display === 'none' || cs.visibility === 'hidden' || Number(cs.opacity) === 0) {
            return;
          }
          var rect = el.getBoundingClientRect();
          if (rect.width <= 0 || rect.height <= 0) return;
          var top = rect.top - baseRect.top;
          var bottom = rect.bottom - baseRect.top;
          if (bottom - top > 600) return;
          minTop = Math.min(minTop, top);
          maxBottom = Math.max(maxBottom, bottom);
        });

      var h = Math.ceil(maxBottom - minTop + 8);
      if (expanded) {
        h = Math.min(Math.max(h, 200), EXPANDED_MAX);
      } else {
        h = Math.min(Math.max(h, COLLAPSED_MIN), COLLAPSED_MAX);
      }

      // Keep content bottom-aligned via body flex-end — do NOT shift with marginTop (breaks hover).
      target.style.marginTop = '';
      if (h > 0 && h !== prev) {
        prev = h;
        if (window.parent !== window) {
          window.parent.postMessage({ type: 'premiumbar-resize', height: h }, '*');
        }
      }

    }

    window.__measureExpandedBounds = measure;
    new ResizeObserver(measure).observe(target);
    window.addEventListener('load', measure);
    window.addEventListener('resize', measure);
    document.addEventListener(
      'transitionend',
      function (e) {
        if (e.target && e.target.closest && e.target.closest('.ollincd')) measure();
      },
      true
    );
    var n = 0;
    var poll = setInterval(function () {
      measure();
      if (++n > 50) clearInterval(poll);
    }, 250);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', setupPremiumBarExpandedResize);
  } else {
    setupPremiumBarExpandedResize();
  }
})();

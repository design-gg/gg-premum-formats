window.addEventListener("load", function() {

	let banner;
	if(banner = document.querySelector(".PremiumBarGG")) {

		banner.classList.add("PremiumBarGG-showup");
		setTimeout(() => {			
			// PremiumBarGG.animateBottlesOnLoad();
		}, 1000);

		if (window.matchMedia("(min-width:600px)").matches) {
			banner.style.willChange = "height, scale";
			banner.querySelector(".PremiumBarGG-video").style.willChange = "height";
			banner.querySelector(".PremiumBarGG-about").style.willChange = "height";
			let trg;
			banner.addEventListener("mouseenter", function() {
				if(PremiumBarGG.tlBottles) PremiumBarGG.tlBottles.kill();
				trg = event.target;
				setTimeout(() => {
					trg.classList.add("PremiumBarGG-hovered");
				}, 0);
			});
			banner.addEventListener("mouseleave", function() {
				event.target.classList.remove("PremiumBarGG-hovered");
				event.target.classList.add("PremiumBarGG-unhover");
				setTimeout(() => {
					banner.classList.remove("PremiumBarGG-unhover");
					banner.querySelector(".PremiumBarGG-video").style.removeProperty("will-change");
					banner.querySelector(".PremiumBarGG-about").style.removeProperty("will-change");					
					// PremiumBarGG.animateBottlesOnLoad();
				}, 500);
			});

			setTimeout(() => {
				banner.style.willChange = "auto";
			}, 1000);
		}
		else {
			// for mobile expand banner on load page
			banner.style.willChange = "height, scale";
			banner.querySelector(".PremiumBarGG-video").style.willChange = "width, left";
			banner.querySelector(".PremiumBarGG-about").style.willChange = "width, margin-left, height";
			banner.classList.add("PremiumBarGG-showup", "PremiumBarGG-expand", "PremiumBarGG-expanded");			
			PremiumBarGG.getEndingVideo(banner);

			PremiumBarGG._banner = banner;
			PremiumBarGG.onLoadScrollPosition = window.scrollY;
			window.addEventListener("scroll", PremiumBarGG.handleScroll);
			document.addEventListener("touchmove", PremiumBarGG.handleScroll, { passive: true });
		}

		let touchstartY = 0;
		let touchendY = 0;

		function checkDirection() {
			if (touchendY < touchstartY) {
				if(banner = document.querySelector(".PremiumBarGG")) {
					if(PremiumBarGG.touchEndEl) {
						PremiumBarGG.expand(banner, false, "down");
					}
				}
			}
			if (touchendY > touchstartY) {
				if(banner = document.querySelector(".PremiumBarGG")) {
					if(PremiumBarGG.touchstartEl) {
						PremiumBarGG.expand(banner, false, "up");
					}
				}
			}
		}

		document.addEventListener('touchstart', (e) => {
			PremiumBarGG.touchstartEl = false;
			if(e.target.closest(".PremiumBarGG")) {
				PremiumBarGG.touchstartEl = true;
			}
			touchstartY = e.changedTouches[0].screenX;
		});
		
		document.addEventListener('touchend', (e) => {
			PremiumBarGG.touchEndEl = false;
			let touch = e.changedTouches[0];
			let _touchEndEl = document.elementFromPoint(touch.clientX, touch.clientY);
			touchendY = touch.screenX;
			if(_touchEndEl.closest(".PremiumBarGG")) {
				PremiumBarGG.touchEndEl = true;
			}
			
			checkDirection();			
		});
	}			
})

var PremiumBarGG = {
	tlBottles: undefined,
	toggleMute: function(sender) {
		event.preventDefault();
		event.stopPropagation();
		sender.classList.toggle("mute-on");
		let video = sender.parentNode.querySelector("video");
		let isMuted = video.muted;

		video.muted = !isMuted;

		sender.setAttribute('aria-pressed', isMuted);
		sender.setAttribute('aria-label', !isMuted ? 'Включить звук' : 'Выключить звук');
	},
	expand: function(sender, isClick, direction) {
		let _sender = sender;

		if(isClick) {
			event.preventDefault();
			event.stopPropagation();
			_sender = sender.closest(".PremiumBarGG");
		}
		
		if(_sender.classList.contains("PremiumBarGG-expand")) {
			if(direction && direction != "down") return;
			_sender.classList.remove("PremiumBarGG-expand");
			setTimeout(() => {
				_sender.classList.remove("PremiumBarGG-expanded");
				setTimeout(() => {
					_sender.style.willChange = "auto";
					_sender.querySelector(".PremiumBarGG-video").style.willChange = "auto";
					_sender.querySelector(".PremiumBarGG-about").style.willChange = "auto";
				}, 600)
			}, 15);
		}
		else {
			if(direction && direction != "up") return;
			_sender.style.willChange = "height, scale";
			_sender.querySelector(".PremiumBarGG-video").style.willChange = "width, left";
			_sender.querySelector(".PremiumBarGG-about").style.willChange = "width, margin-left, height";
			_sender.classList.add("PremiumBarGG-expand");
			setTimeout(() => {
				_sender.classList.add("PremiumBarGG-expanded");
			}, 15);
		}
	},
	getEndingVideo: function(banner) {
		const video = banner.querySelector("video");			
		if(!video) return;

		let timerId = setInterval(() => {
			if(video.currentTime >= video.duration - .25) {
				PremiumBarGG.expand(banner, false, "down");
				clearInterval(timerId);
			}
		}, 1000);	
	},
	handleScroll: function() {
		let vpH = window.innerHeight;
		let currentScrollPosition = window.scrollY;
		let fullHeightPage = Math.max(
			document.body.scrollHeight, document.documentElement.scrollHeight,
			document.body.offsetHeight, document.documentElement.offsetHeight,
			document.body.clientHeight, document.documentElement.clientHeight
			);

		if((currentScrollPosition > PremiumBarGG.onLoadScrollPosition) && ((currentScrollPosition - PremiumBarGG.onLoadScrollPosition) >= vpH / 2)) {
			PremiumBarGG.expand(PremiumBarGG._banner, false, "down");
			window.removeEventListener("scroll", PremiumBarGG.handleScroll);
			document.removeEventListener("touchmove", PremiumBarGG.handleScroll);
		}
		if(currentScrollPosition + vpH >= fullHeightPage) {
			PremiumBarGG.expand(PremiumBarGG._banner, false, "down");
			window.removeEventListener("scroll", PremiumBarGG.handleScroll);
			document.removeEventListener("touchmove", PremiumBarGG.handleScroll);
		}
	},
	animateBottlesOnLoad: function() {
		if (window.matchMedia("(min-width:600px)").matches) {
			bottles = gsap.utils.toArray(document.querySelectorAll(".PremiumBarGG .PremiumBarGG-bottle"));
			PremiumBarGG.tlBottles = gsap.timeline({onComplete: _f, repeatRefresh: true});
			
			// showBottlesTimeout = setTimeout(_f, 0);
		
			function _f() {	
				PremiumBarGG.tlBottles.to(bottles, {
					duration: 3,
					y: "random(0, 18)",
					ease: "linear",
					stagger: .1
				});
			}
		}		
	}


}
